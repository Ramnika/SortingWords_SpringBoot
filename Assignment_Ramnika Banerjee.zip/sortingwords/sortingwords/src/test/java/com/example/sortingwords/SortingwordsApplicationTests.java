package com.example.sortingwords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SortingwordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
