package com.example.sortingwords;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

class WordSortingControllerTest {

    @Test //test for sorting according to length
    void testSortWordsByLength() {
        WordSortingController controller = new WordSortingController();
        String[] words = {"consider", "how", "my", "light", "is", "spent"};
        String sorting = "length";
        List<String> expected = List.of("is","my", "how", "light", "spent","consider");

        List<String> result = controller.sortWords(words, sorting);//Hey I am Ramnika Banerjee= am Banerjee Hey I Ramnika

        assertEquals(expected, result);
    }

    @Test //test for sorting according to alphabetical order
    void testSortWordsAlphabetically() {
        WordSortingController controller = new WordSortingController();
        String[] words = {"how", "is", "light", "my","queue"};
        String sorting = "alphabetical";
        List<String> expected = List.of("how", "is", "light", "my","queue");

        List<String> result = controller.sortWords(words, sorting);

        assertEquals(expected, result);
    }
    @Test //test for sorting according to alphabetical order
    void test2SortWordsAlphabetically() {
        WordSortingController controller = new WordSortingController();
        String[] words = {"hey", "i", "am", "ramnika","banerjee"};
        String sorting = "alphabetical";
        List<String> expected = List.of("am", "banerjee", "hey", "i","ramnika");

        List<String> result = controller.sortWords(words, sorting);

        assertEquals(expected, result);
    }
}
