package com.example.sortingwords;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SortingWordsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SortingWordsApplication.class, args);
    }
}

@RestController
class WordSortingController {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WordSortingController.class);
    
    @PostMapping("/sortWords")
    public List<String> sortWords(@RequestParam int count, @RequestParam String sorting, @RequestBody String text) {
        LOGGER.info("Received request to sort words. Count: {}, Sorting: {}, Text: {}", count, sorting, text);
        
        // Split the text into words
        String[] words = text.split("\\s+");
        
        // Sort the words based on the given sorting order
        List<String> sortedWords = sortWords(words, sorting);
        
        // Get the top N largest words
        List<String> topNWords = getTopNWords(sortedWords, count);
        
        LOGGER.info("Returning sorted words: {}", topNWords);
        return topNWords;
    }
    List<String> sortWords(String[] words, String sorting) {
    	List<String> wordList = Arrays.asList(words);
        Comparator<String> comparator;
        
        if (sorting.equalsIgnoreCase("length")) {
            comparator = Comparator.comparingInt(String::length)
                    .thenComparing(Comparator.naturalOrder());
        } else {
            comparator = Comparator.naturalOrder();
        }
        
        wordList.sort(comparator);
        return wordList;
    }
    
    List<String> getTopNWords(List<String> words, int count) {
        if (count >= words.size()) {
            return words;
        } else {
            return words.subList(words.size() - count, words.size());
        }
    }
}
